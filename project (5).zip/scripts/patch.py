import os,shutil
res='android/app/src/main/res'
shutil.rmtree(res+'/mipmap-anydpi-v26',ignore_errors=True)
for dn in ('mdpi','hdpi','xhdpi','xxhdpi','xxxhdpi'):
    os.makedirs(f'{res}/mipmap-{dn}',exist_ok=True)
    shutil.copy(f'resources/icons/{dn}.png',f'{res}/mipmap-{dn}/ic_launcher.png')
    shutil.copy(f'resources/icons/{dn}_round.png',f'{res}/mipmap-{dn}/ic_launcher_round.png')
    shutil.copy(f'resources/icons/{dn}.png',f'{res}/mipmap-{dn}/ic_launcher_foreground.png')
    os.makedirs(f'{res}/drawable-{dn}',exist_ok=True)
    shutil.copy(f'resources/stat/{dn}.png',f'{res}/drawable-{dn}/ic_stat_noor.png')
os.makedirs(res+'/raw',exist_ok=True)
shutil.copy('resources/adhan.mp3',res+'/raw/adhan.mp3')
p='android/app/src/main/AndroidManifest.xml'
s=open(p,encoding='utf-8').read()
perms=['ACCESS_COARSE_LOCATION','ACCESS_FINE_LOCATION','POST_NOTIFICATIONS','SCHEDULE_EXACT_ALARM','USE_EXACT_ALARM','RECORD_AUDIO','VIBRATE','RECEIVE_BOOT_COMPLETED','WAKE_LOCK']
add=''.join('<uses-permission android:name="android.permission.%s"/>'%x for x in perms)
s=s.replace('</manifest>',add+'</manifest>')
open(p,'w',encoding='utf-8').write(s)
print('patched')
